import {
	defineStore
} from 'pinia'
import tui from '/utils/httpRequest'
import websocketUtil from '/utils/websocket';
export const useUserStore = defineStore('user', {
	state: () => {
		return {
			user: {},
			city: '位置',
			chooseAddress: {
				province: "",
				city: "",
				area: "",
				address: "",
			},
			socket: ""
		}   
	},
	actions: {
		// 更新用户信息
		async updateUser() {
			// Demo: 若无 token，自动设置演示 token 以通过 isLogin() 校验
			if (!tui.getToken()) {
				tui.setToken('demo_token_001')
			}
			if (tui.getToken()) {
				try {
					let res = await tui.request('User/GetUser')
					this.user = res.data
				} catch (e) {
					// Demo: 后端不可用时使用模拟用户
					this.user = {
						userId: 'demo_user_001',
						nickName: '花艺演示用户',
						avatar: '/static/logo.png',
						mobile: '138****8888',
						shopAuditStatus: 1
					}
				}
			} else {
				// Demo: 无token时也使用模拟用户（方便本地调试）
				this.user = {
					userId: 'demo_user_001',
					nickName: '花艺演示用户',
					avatar: '/static/logo.png',
					mobile: '138****8888',
					shopAuditStatus: 1
				}
			}
		},
		// 选择地址
		chooseRegion() {
			//获取位置
			uni.getLocation({
				type: 'gcj02',
				success: (res) => {
					uni.chooseLocation({
						latitude: res.latitude,
						longitude: res.longitude,
						success: (res2) => {
							this.chooseAddress.address = res2.name
							let addressTemp = tui.captureLocation(res2)
							this.chooseAddress.province = addressTemp.province;
							this.chooseAddress.city = addressTemp.city;
							this.chooseAddress.area = addressTemp.area;
							this.city = addressTemp.city
						}
					});
				},
				fail(error) {
					console.log('获取位置失败', error)
				}
			})
		},
		// 链接websocket
		connectSocketInit() {
			if (tui.getToken()) {
				//开启websocket
				tui.request('Chat/preConnect').then(res => {
					this.socket = new websocketUtil(
						res.data,
						3000
					);
				})
			}
		}
	},
	unistorage: true, // 是否持久化
})