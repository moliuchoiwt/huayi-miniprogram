<template>
	<view>
		<view class="pageBg"></view>
		<view class="box">
			<up-navbar title=" " bgColor='#ffffff00' title-color="#fff" leftIcon='' :fixed="false" placeholder>
				<template #left>
					<!-- <image class="logo" src="/static/logoLine.png" mode="heightFix"></image> -->
					<image class="logo" src="/static/logo.png" mode="heightFix"></image>
				</template>
			</up-navbar>
			<view class="search">
				<up-search placeholder="搜索" bgColor='#fff' :clearabled="false" :showAction="false" height="88rpx"
					shape="square" @search="toList"></up-search>
			</view>
			<view class="swiper">
				<up-swiper :list="showBannerList" height="328rpx" keyName="imgUrl" indicator indicatorMode="dot" circular
					@click="clickSwpier"></up-swiper>
			</view>
			<view class="menus">
				<view class="menu" @click="href('/pagesPerson/info', true)">
					<view class="texts">
						<view class="name">信息填写</view>
						<view class="text">个人信息完善</view>
					</view>
					<image src="/static/icon01.png"></image>
				</view>
				<view class="menu" @click="href('/pagesShop/shop/add', true)" v-if="!MpWxOpenCheck">
					<view class="texts">
						<view class="name">花店入驻</view>
						<view class="text">入驻发布任务</view>
					</view>
					<image src="/static/icon02.png"></image>
				</view>
			</view>
			<view style="margin:32rpx 0;">
				<u-title>任务订单</u-title>
			</view>
			<view class="list">
				<view class="item" v-for="item in showList" :key="item.Id"
					@click="href(`/pagesShop/task/detail?id=${item.Id}`)">
					<view class="header">
						<view v-if="item.isDemo" class="imgPlaceholder" :style="{ background: item.bgColor }">
							<text class="emoji">{{ item.emoji }}</text>
						</view>
						<image v-else :src="item.goodsImgList[0]" mode="aspectFill"></image>
						<view class="name">
							<view class="text">
								{{ item.relatedDemand }}
							</view>
						</view>
					</view>
					<view class="info">
						<view class="left">
							<view class="time">
								<view>
									<image src="/static/icon04.png"></image>
								</view>
								<view class="text">收货时间{{ item.receivingTime }}</view>
							</view>
							<view class="business">
								<view class="shop">
									<image class="icon" src="/static/icon03.png" mode="widthFix"></image>
									<view class="name">{{ item.shopName }}</view>
								</view>
								<view class="createTime" v-if="!item.isDemo">
									<uni-dateformat :date="new Date(item.createTime)" :threshold="[60000, 3600000]"
										format="yyyy-MM-dd hh"></uni-dateformat>
									·发布
								</view>
								<view class="createTime" v-if="item.isDemo">
									{{ item.createTime }}
								</view>
							</view>
						</view>
						<view class="right">
							<view class="price">￥{{ item.price }}</view>
							<view class="btn">申请接单</view>
						</view>
					</view>
				</view>
			</view>
			<view class="emptyBlock" v-if="showList.length <= 0">
				<image src="/static/img32.png" mode="widthFix"></image>
			</view>
		</view>
		<up-overlay :show="show" @click="show = false">
			<view class="overlay">  
				<view class="body"> 
					<image class="bg" src="/static/img32.png"></image>
				</view>
			</view>
		</up-overlay>
	</view>
</template> 

<script>
const demoBannerList = [
	{ imgUrl: '/static/img31.png', Link: '' },
	{ imgUrl: '/static/img31.png', Link: '' },
	{ imgUrl: '/static/img31.png', Link: '' }
]
const demoTaskList = [
	{ Id: 'demo1', goodsImgList: [''], emoji: '🌹', bgColor: 'linear-gradient(135deg, #ffd1dc 0%, #ff9eb5 100%)', relatedDemand: '【演示】红玫瑰花束 99朵情人节礼盒', receivingTime: '2024-08-15', shopName: '花语花坊', createTime: '2024-08-08', price: '299.00', isDemo: true },
	{ Id: 'demo2', goodsImgList: [''], emoji: '💐', bgColor: 'linear-gradient(135deg, #fff4b8 0%, #ffd166 100%)', relatedDemand: '【演示】开业花篮一对 大麦花篮庆典开业', receivingTime: '2024-08-20', shopName: '四季花店', createTime: '2024-08-08', price: '588.00', isDemo: true },
	{ Id: 'demo3', goodsImgList: [''], emoji: '🌻', bgColor: 'linear-gradient(135deg, #c8e6c9 0%, #81c784 100%)', relatedDemand: '【演示】韩式花束 毕业季向日葵花束', receivingTime: '2024-08-18', shopName: '花时间花店', createTime: '2024-08-08', price: '168.00', isDemo: true }
]

export default {
	data() {
		return {
			bannerList: [],
			bannerObj: {},
			list: [], 
			show: true,
			query: {
				pageNum: 1,
				pageSize: 10,
				queryName: ""
			},
			total: 0,
			MpWxOpenCheck: false
		}
	},
	computed: {
		showBannerList() {
			return this.bannerList.length > 0 ? this.bannerList : demoBannerList
		},
		showList() {
			return this.list.length > 0 ? this.list : demoTaskList
		}
	},
	onLoad() {
		// Demo 模式：不使用 API
	},
	onPullDownRefresh() {
		uni.stopPullDownRefresh()
	},
	onShow() {
		// Demo 模式：不使用 API
	},
	onReachBottom() {
		this.toast('没有更多了')
	},
	methods: {
		clickSwpier(e) {
			this.href(this.showBannerList[e].Link)
		},
		toList(e) {
			this.href(`/pagesShop/task/list?queryName=${e}`)
		}
	}
}
</script>

<style lang="scss" scoped>
:deep(.u-navbar__content__left) {
	padding: 0 !important;
}

.pageBg {
	width: 750rpx;
	height: 380rpx;
	background: linear-gradient(180deg, #7B2FBE 0%, #A855F7 60%, rgba(168, 85, 247, 0) 100%);
}

.box {
	position: absolute;
	left: 0;
	top: 0;
	width: 750rpx;
	padding: 0 28rpx;

	.logo {
		height: 80rpx;
	}

	.search {
		margin-top: 32rpx;
	}

	.swiper {
		margin-top: 32rpx;
	}

	.menus {
		margin-top: 24rpx;
		display: flex;
		justify-content: space-between;

		.menu {
			display: flex;
			justify-content: space-between;
			background: #ffffff;
			border-radius: 16rpx;
			padding: 32rpx;
			width: 100%;

			.texts {
				.name {
					font-weight: 600;
					font-size: 32rpx;
					color: #333333;
				}

				.text {
					font-size: 20rpx;
					color: #666666;
					margin-top: 10rpx;
				}
			}

			image {
				width: 88rpx;
				height: 88rpx;
			}
		}

		.menu:not(:nth-child(1)) {
			margin-left: 26rpx;
		}
	}

	.list {
		.item {
			margin-bottom: 24rpx;
			background: #FFFFFF;
			border-radius: 16rpx;
			padding: 24rpx;

			.header {
				display: flex;

				image {
					width: 128rpx;
					height: 128rpx;
					border-radius: 8rpx;
				}

				.imgPlaceholder {
					width: 128rpx;
					height: 128rpx;
					border-radius: 8rpx;
					display: flex;
					align-items: center;
					justify-content: center;
					flex-shrink: 0;

					.emoji {
						font-size: 72rpx;
						line-height: 1;
					}
				}

				.name {
					flex: 1;
					margin-left: 20rpx;
					font-size: 32rpx;
					color: #333333;

					.text {
						overflow: hidden;
						text-overflow: ellipsis;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
					}
				}
			}

			.info {
				display: flex;
				justify-content: space-between;
				margin-top: 16rpx;

				.left {
					flex: 1;

					.time {
						display: flex;
						align-items: center;
						padding: 14rpx 18rpx;
						background: linear-gradient(90deg, #F5F5F5 70%, rgba(245, 245, 245, 0) 100%);

						image {
							width: 32rpx;
							height: 32rpx;
						}

						.text {
							font-size: 24rpx;
							color: #666666;
							margin-left: 6rpx;
						}
					}

					.business {
						flex: 1;
						display: flex;
						justify-content: space-between;
						align-items: center;
						margin-top: 40rpx;

						.shop {
							display: flex;
							align-items: center;

							.icon {
								width: 44rpx;
								height: 44rpx;
							}

							.name {
								white-space: nowrap;
								margin-left: 6rpx;
								font-size: 24rpx;
								color: #333333;
							}
						}

						.createTime {
							padding-right: 56rpx;
							font-size: 24rpx;
							color: #666666;
						}
					}
				}

				.right {
					display: flex;
					flex-direction: column;
					align-items: flex-end;

					.price {
						font-weight: 600;
						font-size: 40rpx;
						color: #DE4343;
					}

					.btn {
						margin-top: 16rpx;
						width: 192rpx;
						height: 64rpx;
						background: #262626;
						border-radius: 16rpx;
						display: flex;
						align-items: center;
						justify-content: center;
						font-size: 28rpx;
						color: #FFFFFF;
					}
				}
			}
		}
	}
}

.overlay {
	width: 100%;
	height: 100vh;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 0 72rpx;

	.body {
		position: relative;

		.bg {
			width: 606rpx;
			height: 606rpx;
		}

	}

}
</style>
