<template>
	<view class="container">
		<up-navbar :title="chatName" :autoBack="true" bgColor="#ffffff"></up-navbar>
		<scroll-view class="msg-list" scroll-y :scroll-top="scrollTop" @scrolltolower="loadMore">
			<view class="msg-item" v-for="(item, index) in messages" :key="index"
				:class="item.fromUserId == myId ? 'msg-right' : 'msg-left'">
				<image class="avatar" :src="item.fromAvatar || '/static/logo.png'" mode="aspectFill" />
				<view class="bubble">
					<text class="text">{{ item.contents }}</text>
					<text class="time">{{ formatTime(item.createTime) }}</text>
				</view>
			</view>
			<view v-if="loading" class="loading">加载中...</view>
		</scroll-view>
		<view class="input-bar">
			<input class="input" v-model="inputMsg" placeholder="请输入消息" confirm-type="send" @confirm="send" />
			<view class="send-btn" @click="send">发送</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				sessionId: '',
				chatName: '聊天',
				myId: 0,
				messages: [],
				inputMsg: '',
				pageNum: 1,
				pageSize: 20,
				loading: false,
				scrollTop: 0,
				noMore: false
			}
		},
		onLoad(options) {
			this.sessionId = options.sessionId || ''
			this.chatName = decodeURIComponent(options.name || '聊天')
			this.myId = this.storeUser?.user?.userId || 0
			this.getHistory()
		},
		methods: {
			async getHistory() {
				if (this.loading || this.noMore) return
				this.loading = true
				const res = await this.request('Message/History', {
					sessionId: this.sessionId,
					pageNum: this.pageNum,
					pageSize: this.pageSize
				})
				this.loading = false
				if (res.code == 200) {
					const items = res.data?.items || []
					if (items.length < this.pageSize) this.noMore = true
					this.messages = this.pageNum == 1 ? items.reverse() : [...items.reverse(), ...this.messages]
					this.pageNum++
				}
			},
			loadMore() {
				this.getHistory()
			},
			async send() {
				if (!this.inputMsg.trim()) return
				const res = await this.request('Message/Send', {
					msgType: 1,
					sessionId: this.sessionId,
					contents: this.inputMsg.trim()
				})
				if (res.code == 200) {
					this.messages.push({
						fromUserId: this.myId,
						contents: this.inputMsg.trim(),
						createTime: new Date().toISOString()
					})
					this.inputMsg = ''
					this.scrollToBottom()
				}
			},
			scrollToBottom() {
				this.scrollTop = this.messages.length * 100 + 100
			},
			formatTime(t) {
				if (!t) return ''
				const d = new Date(t)
				return `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { display: flex; flex-direction: column; height: 100vh; background: #f5f5f5; }
	.msg-list { flex: 1; padding: 20rpx; overflow-y: auto; }
	.msg-item { display: flex; align-items: flex-start; margin-bottom: 24rpx; }
	.msg-left { flex-direction: row; }
	.msg-right { flex-direction: row-reverse; }
	.avatar { width: 72rpx; height: 72rpx; border-radius: 50%; margin: 0 16rpx; }
	.bubble {
		max-width: 60%; padding: 20rpx 24rpx;
		border-radius: 16rpx; background: #fff;
		position: relative;
	}
	.msg-right .bubble { background: #8C4FFF; }
	.msg-right .bubble .text { color: #fff; }
	.text { font-size: 28rpx; color: #333; line-height: 1.5; word-break: break-all; }
	.time { font-size: 22rpx; color: #999; margin-top: 8rpx; display: block; text-align: right; }
	.msg-right .time { color: rgba(255,255,255,0.7); }
	.input-bar {
		display: flex; align-items: center;
		padding: 20rpx; background: #fff;
		border-top: 1rpx solid #eee;
	}
	.input { flex: 1; height: 72rpx; background: #f5f5f5; border-radius: 36rpx; padding: 0 24rpx; font-size: 28rpx; }
	.send-btn {
		margin-left: 20rpx; padding: 0 32rpx; height: 72rpx; line-height: 72rpx;
		background: #8C4FFF; color: #fff; border-radius: 36rpx; font-size: 28rpx;
	}
	.loading { text-align: center; font-size: 24rpx; color: #999; padding: 20rpx; }
</style>
