<template>
	<view class="container">
		<up-navbar title="消息" :autoBack="false" :placeholder="true" bgColor="#ffffff">
		</up-navbar>
		<view class="session-list" v-if="list.length > 0">
			<view class="session-item" v-for="(item, index) in list" :key="index" @click="goChat(item)">
				<view class="avatar-box">
					<image class="avatar" :src="item.avatar || '/static/logo.png'" mode="aspectFill" />
					<view class="badge" v-if="item.unreadCount > 0">{{ item.unreadCount > 99 ? '99+' : item.unreadCount }}</view>
				</view>
				<view class="content">
					<view class="top">
						<text class="name">{{ item.name || '系统消息' }}</text>
						<text class="time">{{ formatTime(item.lastTime) }}</text>
					</view>
					<view class="bottom">
						<text class="msg" :class="{ unread: item.unreadCount > 0 }">{{ item.lastMsg || '' }}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="empty" v-else>
			<image src="/static/img31.png" mode="aspectFit" class="empty-img" />
			<text class="empty-text">暂无消息</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
				pageNum: 1,
				pageSize: 20
			}
		},
		onShow() {
			this.getList()
		},
		methods: {
			async getList() {
				const res = await this.request('Message/SessionList', {
					pageNum: this.pageNum,
					pageSize: this.pageSize
				})
				if (res.code == 200) {
					this.list = res.data?.items || []
				}
			},
			goChat(item) {
				uni.navigateTo({
					url: `/pages/message/chat?sessionId=${item.sessionId}&name=${encodeURIComponent(item.name || '聊天')}`
				})
			},
			formatTime(t) {
				if (!t) return ''
				const d = new Date(t)
				const now = new Date()
				if (d.toDateString() === now.toDateString()) {
					return `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`
				}
				return `${d.getMonth()+1}/${d.getDate()}`
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { min-height: 100vh; background: #f5f5f5; }
	.session-list { padding: 20rpx; }
	.session-item {
		display: flex; align-items: center;
		background: #fff; border-radius: 16rpx;
		padding: 24rpx; margin-bottom: 20rpx;
	}
	.avatar-box { position: relative; margin-right: 24rpx; }
	.avatar { width: 88rpx; height: 88rpx; border-radius: 50%; }
	.badge {
		position: absolute; top: -4rpx; right: -4rpx;
		background: #ff4d4f; color: #fff; font-size: 22rpx;
		min-width: 36rpx; height: 36rpx; border-radius: 18rpx;
		display: flex; align-items: center; justify-content: center;
		padding: 0 8rpx;
	}
	.content { flex: 1; overflow: hidden; }
	.top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8rpx; }
	.name { font-size: 30rpx; color: #333; font-weight: 500; }
	.time { font-size: 24rpx; color: #999; }
	.bottom { display: flex; align-items: center; }
	.msg { font-size: 26rpx; color: #999; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.msg.unread { color: #333; font-weight: 500; }
	.empty { display: flex; flex-direction: column; align-items: center; padding-top: 200rpx; }
	.empty-img { width: 240rpx; height: 240rpx; margin-bottom: 30rpx; }
	.empty-text { font-size: 28rpx; color: #999; }
</style>
