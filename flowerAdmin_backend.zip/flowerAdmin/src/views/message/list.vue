<template>
  <div class="table-box">
    <ProTable ref="proTable" :columns="columns" :request-api="sysMsgApi.list" default-expand-all>
      <template #tableHeader>
        <el-button type="primary" :icon="CirclePlus" @click="openDialog()">新增公告</el-button>
      </template>
      <template #msgType="scope">
        <el-tag :type="msgTypeTag(scope.row.msgType)">{{ msgTypeLabel(scope.row.msgType) }}</el-tag>
      </template>
      <template #contents="scope">
        <div class="msg-preview">{{ scope.row.contents }}</div>
      </template>
      <template #readState="scope">
        <el-tag :type="scope.row.readState == 0 ? 'danger' : 'success'">{{ scope.row.readState == 0 ? '未读' : '已读' }}</el-tag>
      </template>
      <template #operation="scope">
        <el-button type="primary" link :icon="View" @click="replyDialog(scope.row)">回复</el-button>
        <el-button type="danger" link :icon="Delete" @click="delMsg(scope.row)">删除</el-button>
      </template>
    </ProTable>

    <!-- 回复对话框 -->
    <el-dialog v-model="dialogVisible" title="回复消息" width="600px">
      <div class="chat-history" v-if="currentSession.length > 0">
        <div v-for="(item, idx) in currentSession" :key="idx" class="chat-item" :class="item.fromUserId == 0 ? 'chat-right' : 'chat-left'">
          <div class="chat-bubble">
            <div class="chat-sender">{{ item.fromUserId == 0 ? '客服' : '用户' + item.fromUserId }}</div>
            <div class="chat-text">{{ item.contents }}</div>
            <div class="chat-time">{{ item.createTime }}</div>
          </div>
        </div>
      </div>
      <div v-else class="no-history">暂无历史消息</div>
      <el-input v-model="replyContent" type="textarea" :rows="3" placeholder="请输入回复内容" />
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitReply">发送</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts" name="messageList">
import { ref } from "vue";
import { ColumnProps } from "@/components/ProTable/interface";
import { Delete, CirclePlus, View } from "@element-plus/icons-vue";
import ProTable from "@/components/ProTable/index.vue";
import { sysMsgApi } from "@/api/api";
import { useHandleData } from "@/hooks/useHandleData";
import { ElMessage } from "element-plus";

const proTable = ref();
const dialogVisible = ref(false);
const replyContent = ref("");
const currentRow = ref<any>({});
const currentSession = ref<any[]>([]);

const msgTypeLabel = (t: number) => {
  const map: Record<number, string> = { 0: "系统公告", 1: "用户聊天", 2: "客服聊天", 3: "订单通知", 4: "评价通知" };
  return map[t] || "其他";
};
const msgTypeTag = (t: number) => {
  const map: Record<number, string> = { 0: "info", 1: "", 2: "success", 3: "warning", 4: "danger" };
  return map[t] || "info";
};

const columns = ref<ColumnProps[]>([
  { prop: "queryName", label: "搜索", isShow: false, isSetting: false, search: { el: "input", key: "queryName", label: "搜索" } },
  { prop: "Id", label: "ID", width: 80, fixed: "left" },
  { prop: "msgType", label: "类型", width: 100 },
  { prop: "fromUserId", label: "发送方", width: 100 },
  { prop: "toUserId", label: "接收方", width: 100 },
  { prop: "title", label: "标题", minWidth: 150 },
  { prop: "contents", label: "内容", minWidth: 250 },
  { prop: "readState", label: "阅读状态", width: 90 },
  { prop: "createTime", label: "创建时间", minWidth: 180 },
  { prop: "operation", label: "操作", minWidth: 180, fixed: "right" }
]);

const openDialog = () => {
  // 新增系统公告（简化：直接调用API）
  ElMessage.info("请调用 sysMsgApi.operation 新增公告");
};

const replyDialog = async (row: any) => {
  currentRow.value = row;
  dialogVisible.value = true;
  replyContent.value = "";
  // 加载同 session 的历史消息
  if (row.sessionId) {
    const res = await sysMsgApi.history({ sessionId: row.sessionId, pageNum: 1, pageSize: 50 });
    currentSession.value = res.data?.items || [];
  }
};

const submitReply = async () => {
  if (!replyContent.value.trim()) return;
  const res = await sysMsgApi.reply({
    sessionId: currentRow.value.sessionId,
    toUserId: currentRow.value.fromUserId || currentRow.value.toUserId,
    contents: replyContent.value.trim(),
    msgType: 2 // 客服聊天
  });
  if (res.code == 200) {
    ElMessage.success("回复成功");
    dialogVisible.value = false;
    proTable.value?.getTableList();
  }
};

const delMsg = async (row: any) => {
  await useHandleData(sysMsgApi.del, { ids: [row.Id] }, `删除消息【${row.title || row.contents?.substring(0, 20)}】`);
  proTable.value?.getTableList();
};
</script>

<style scoped>
.msg-preview { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px; }
.chat-history { max-height: 400px; overflow-y: auto; margin-bottom: 20px; padding: 10px; background: #f5f5f5; border-radius: 8px; }
.chat-item { margin-bottom: 16px; display: flex; }
.chat-left { justify-content: flex-start; }
.chat-right { justify-content: flex-end; }
.chat-bubble { max-width: 70%; padding: 12px 16px; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
.chat-right .chat-bubble { background: #8C4FFF; color: #fff; }
.chat-sender { font-size: 12px; color: #999; margin-bottom: 4px; }
.chat-right .chat-sender { color: rgba(255,255,255,0.7); }
.chat-text { font-size: 14px; line-height: 1.5; word-break: break-all; }
.chat-time { font-size: 12px; color: #999; margin-top: 4px; text-align: right; }
.chat-right .chat-time { color: rgba(255,255,255,0.6); }
.no-history { text-align: center; color: #999; padding: 40px; }
</style>
