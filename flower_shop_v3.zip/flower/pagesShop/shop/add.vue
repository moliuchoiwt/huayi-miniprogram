<template>
    <view>
        <view class="form">
            <up-form labelPosition="top" label-width="700rpx">
                <up-form-item label="花店名称" required>
                    <up-input v-model="query.name" placeholder="请填写花店名称"></up-input>
                </up-form-item>
                <up-form-item label="营业执照照片" required>
                    <view style="display: flex;align-items: center;">
                        <!-- 用自定义 @click 触发 chooseMedia，绕过 up-upload 的权限问题 -->
                        <view class="uploadBox" @click="chooseBusinessImg" v-if="!query.businessImg">
                            <image src="/static/icon16.png"></image>
                            <view class="text">上传照片</view>
                        </view>
                        <view class="uploadBox" v-else @click="previewBusinessImg">
                            <image :src="query.businessImg" mode="aspectFill" style="width:100%;height:100%;border-radius:8rpx;"></image>
                            <view class="text" style="color:#ff4d4f;" @click.stop="deleteBusinessImg">删除</view>
                        </view>
                        <view style="font-size: 20rpx;color: #999999;margin-left: 24rpx;">
                            新办理的营业执照，因国家市场监督管理总局信息更新有延迟，建议在办理成功后等待至少14个工作日后再进入入驻
                        </view>
                    </view>
                </up-form-item>
                <up-form-item label="所在地区" required>
                    <view
                        style="display: flex;align-items: center;justify-content: space-between;width: 100%;padding: 12rpx 0;">
                        <picker mode="region" @change="bindTimeChange">
                            <up-input placeholder="请选择省市区" type="text" readonly v-model="addressName" border="none" />
                        </picker>
                        <view><up-icon name="arrow-right" color="#969696" size="20"></up-icon></view>
                    </view>
                </up-form-item>
                <up-form-item label="详细地址" required>
                    <up-textarea v-model="query.address" placeholder="请选择详细地址具体到街道门牌号"></up-textarea>
                </up-form-item>
                <up-form-item label="联系人姓名" required>
                    <up-input v-model="query.realName" placeholder="请填写联系人姓名"></up-input>
                </up-form-item>
                <up-form-item label="联系人电话" required>
                    <up-input v-model="query.mobile" type="number" placeholder="请填写联系人电话"></up-input>
                </up-form-item>
            </up-form>
        </view>

        <!-- 审核状态提示 -->
        <view v-if="auditNotice" class="audit-notice" :class="auditNoticeType">
            <text class="audit-notice-title">📢 审核通知</text>
            <text class="audit-notice-text">{{ auditNotice }}</text>
        </view>

        <view class="btns">
            <view class="btn" :class="{ disabled: btnDisabled }" @click="submit">{{ btnText }}</view>
        </view>
    </view>
</template>

<script>
import {
    test
} from '@/uni_modules/uview-plus';
export default {
    data() {
        return {
            query: {
                name: '',
                businessImg: '',
                province: '',
                city: '',
                area: '',
                address: '',
                realName: '',
                mobile: '',
            },
            fileList1: [],
            auditIntro: '',//驳回原因（从后端 GetShop 返回）
        }
    },
    computed: {
        addressName() {
            let item = this.query
            if (!item.province) return ''
            return item.province + ' ' + item.city + ' ' + item.area
        },
        disabled() {
            return this.storeUser.user.shopAuditStatus == 1
        },
        btnText() {
            // 修正按钮文案
            // shopAuditStatus: -1=未申请 0=审核中 1=已通过 2=被驳回
            // 只有「审核中」禁用并显示「审核中，请耐心等待」
            // 其余状态（-1/1/2）一律显示「申请入驻」，可继续操作
            const status = this.storeUser.user.shopAuditStatus
            if (status == 0) return '审核中，请耐心等待'
            return '申请入驻'
        },
        btnDisabled() {
            // 只有「审核中」状态禁用，其余都可以申请/重新申请
            return this.storeUser.user.shopAuditStatus == 0
        },
        // 审核状态提示（被驳回时显示原因）
        auditNotice() {
            const status = this.storeUser.user.shopAuditStatus
            if (status == 0) return '您的申请正在审核中，请耐心等待'
            if (status == 1) return '您已通过审核，可以随时修改店铺资料'
            if (status == 2) return '您的申请被驳回：' + (this.auditIntro || '请联系客服')
            return ''
        },
        // 提示类型（info/warn/success）
        auditNoticeType() {
            const status = this.storeUser.user.shopAuditStatus
            if (status == 0) return 'info'
            if (status == 1) return 'success'
            if (status == 2) return 'warn'
            return ''
        },
    },
    async onLoad() {
        await this.storeUser.updateUser()
        if (this.storeUser.user.shopAuditStatus == -1) {
            this.query.province = this.storeUser.user.province
            this.query.city = this.storeUser.user.city
            this.query.area = this.storeUser.user.area
            this.query.address = this.storeUser.user.address
            this.query.realName = this.storeUser.user.nickName
            this.query.mobile = this.storeUser.user.mobile
        } else {
            this.request('User/GetShop').then(res => {
                if (res.code == 200) {
                    this.query = res.data.shop
                    this.fileList1 = [{
                        url: this.query.businessImg,
                    }]
                    // 保存驳回原因供显示
                    this.auditIntro = res.data.auditIntro || ''
                }
            })
        }
    },
    methods: {
        chooseAddress() {
            return new Promise((resolve, reject) => {
                uni.chooseAddress({
                    success: (res) => {
                        resolve(res)
                    },
                    fail: (err) => {
                        reject(err)
                    }
                })
            })
        },
        bindTimeChange(e) {
            this.query.province = e.detail.value[0]
            this.query.city = e.detail.value[1]
            this.query.area = e.detail.value[2]
        },
        // 上传营业执照（用 uni.chooseMedia，自带权限申请）
        async chooseBusinessImg() {
            console.log('📸 选择营业执照')
            uni.chooseMedia({
                count: 1,
                mediaType: ['image'],
                sourceType: ['album', 'camera'],
                sizeType: ['compressed'],
                success: async (res) => {
                    console.log('✅ 选择成功:', res)
                    if (res && res.tempFiles && res.tempFiles[0]) {
                        const tempFilePath = res.tempFiles[0].tempFilePath || res.tempFiles[0].path
                        this.toast('上传中...')
                        try {
                            const result = await this.uploadFile(tempFilePath)
                            this.query.businessImg = result
                            uni.hideToast()
                            this.toast('上传成功')
                        } catch (err) {
                            this.toast('上传失败')
                        }
                    }
                },
                fail: (err) => {
                    console.error('❌ 选择失败:', err)
                    if (err.errMsg && err.errMsg.indexOf('cancel') === -1) {
                        uni.showModal({
                            title: '需要相册/相机权限',
                            content: '请在设置中允许使用相册和相机',
                            confirmText: '去设置',
                            success: (res) => {
                                if (res.confirm) {
                                    uni.openSetting()
                                }
                            }
                        })
                    }
                }
            })
        },
        // 预览大图
        previewBusinessImg() {
            if (this.query.businessImg) {
                uni.previewImage({
                    urls: [this.query.businessImg],
                    current: this.query.businessImg
                })
            }
        },
        // 删除营业执照
        deleteBusinessImg() {
            uni.showModal({
                title: '确认删除',
                content: '确定删除这张营业执照照片吗？',
                success: (res) => {
                    if (res.confirm) {
                        this.query.businessImg = ''
                    }
                }
            })
        },
        // 提交
        submit() {
            if (this.btnDisabled) {
                return
            }
            let rules = [
                ['name', '请填写花店名称'],
                ['businessImg', '请上传营业执照照片'],
                ['province', '请选择地址'],
                ['address', '请选择详细地址'],
                ['realName', '请填写联系人姓名'],
                ['mobile', '请填写联系人电话'],
            ]
            for (let i = 0; i < rules.length; i++) {
                let item = rules[i]
                if (!this.query[item[0]]) {
                    this.toast(item[1])
                    return
                }
            }
            if (!test.mobile(this.query.mobile)) {
                this.toast('手机号错误')
                return
            }
            this.request('Shop/SubmitShop', this.query).then(res => {
                this.toast('操作成功')
                setTimeout(() => {
                    this.storeUser.updateUser()
                    this.back()
                }, 400)
            })
        },
    }
}
</script>

<style lang="scss" scoped>
.btns {
    padding: 15rpx 32rpx;
    width: 100%;
    position: fixed;
	z-index: 999;
    left: 0;
    bottom: 0;
    box-shadow: 0rpx 0rpx 16rpx 1rpx rgba(12, 106, 106, 0.1);
    background: #FFFFFF;

    .btn { 
        width: 100%;
        text-align: center;
        padding: 20rpx 0;
        font-size: 28rpx;
        color: #FFFFFF;
        background: #8C4FFF;
        border-radius: 16rpx;
    }
    .btn.disabled {
        background: #cccccc;
        color: #ffffff;
    }
}

.audit-notice {
    margin: 32rpx;
    padding: 24rpx;
    border-radius: 12rpx;
    display: flex;
    flex-direction: column;
    gap: 8rpx;

    .audit-notice-title {
        font-size: 26rpx;
        font-weight: bold;
    }
    .audit-notice-text {
        font-size: 24rpx;
        line-height: 1.5;
    }

    &.info {
        background: #e6f4ff;
        color: #1d6fdb;
        .audit-notice-title { color: #1d6fdb; }
    }
    &.success {
        background: #e8f5e9;
        color: #2e7d32;
        .audit-notice-title { color: #2e7d32; }
    }
    &.warn {
        background: #fff3e0;
        color: #d84315;
        .audit-notice-title { color: #d84315; }
    }
}

.form {
    background: white;
    padding: 0 32rpx;
    width: 686rpx;
    margin: 32rpx;
    border-radius: 16rpx;
}

.item {
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding-right: 32rpx;
}

.uploadBox {
    width: 200rpx;
    height: 200rpx;
    background: #f8f8f8;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 8rpx;

    image {
        width: 56rpx;
        height: 46rpx;
    }
    .text {
        margin-top: 16rpx;
        font-size: 24rpx;
        color: #999999;
    }
}
</style>