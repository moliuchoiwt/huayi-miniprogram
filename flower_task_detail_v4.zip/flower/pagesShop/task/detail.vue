<template>
	<view>
		<!-- 圖片輪播 -->
		<view class="swiper">
			<image v-if="!data.goodsImgList || data.goodsImgList.length === 0" src="/static/logo.png" mode="aspectFill" style="width: 750rpx; height: 750rpx;"></image>
			<up-swiper v-else :list="data.goodsImgList" height="750rpx" indicator indicatorMode="dot" circular></up-swiper>
		</view>

		<!-- Countdown Banner -->
		<view class="countdown">
			<view class="countdown-bg">
				<view class="countdown-left">
					<view class="price">￥{{ info.price || 0 }}</view>
					<view class="text">已付款，平台提供担保</view>
				</view>
				<view class="countdown-right">
					<view class="title">距離收貨</view>
					<view class="time">
						<view class="text">還剩</view>
						<view class="num">{{ countdown.days }}</view>
						<view class="num">{{ countdown.hours }}</view>
						<view class="num">{{ countdown.minutes }}</view>
						<view class="num">{{ countdown.seconds }}</view>
					</view>
				</view>
			</view>
		</view>

		<!-- 訂單信息 -->
		<view class="squareList">
			<view class="square">
				<view class="prices">
					<view class="price">￥{{ info.price ? info.price.toFixed(2) : '0.00' }}</view>
					<view class="texts" @click="href('/pages/common/richText?type=2')">
						<view class="text">接單須知</view>
						<image src="/static/icon21.png"></image>
					</view>
				</view>
				<view class="intro">{{ info.relatedDemand || '暫無描述' }}</view>
			</view>
			<view class="square">
				<view class="item">
					<view class="label">時間</view>
					<view class="right">
						<view class="text">{{ info.receivingTime || '-' }}</view>
					</view>
				</view>
				<view class="item">
					<view class="label">地址</view>
					<view class="right">
						<view class="text">{{ (info.province || '') + (info.city || '') + (info.area || '') + (info.address || '') || '-' }}</view>
					</view>
				</view>
				<view class="item">
					<view class="label">數量</view>
					<view class="right">
						<view class="text">{{ info.quantity || 1 }}</view>
					</view>
				</view>
				<view class="item">
					<view class="label">備註</view>
					<view class="right">
						<view class="text">{{ info.remarks || '暫無備註' }}</view>
					</view>
				</view>
			</view>
		</view>
		<view style="height: 100rpx;"></view>
		<!-- 底部按钮 -->
		<view class="btnBox">
			<view class="btnBuy" @click="$u.throttle(clickApply,1000)">{{data.isApply? '已申请':'申请接单'}}</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			data: {
				goodsImgList: [],
				isApply: false
			},
			info: {
				price: 0,
				receivingTime: '',
				province: '',
				city: '',
				area: '',
				address: '',
				quantity: 1,
				remarks: '',
				relatedDemand: '',
				orderNo: ''
			},
			id: '',
			countdown: {
				days: '00天',
				hours: '00時',
				minutes: '00分',
				seconds: '00秒'
			},
			timer: null
		}
	},
	onLoad(options) {
		this.id = options.id
		this.getGoodsInfo()
	},
	onUnmounted() {
		this.stopCountdown()
	},
	onShow() {
		this.storeUser.updateUser()
	},
	methods: {
		clickApply() {
			if (this.data.isApply) {
				this.modal('提示', '您已申请接单，无需重复申请')
				return
			}
			this.request('Order/ApplyTask', {
				orderNo: this.info.orderNo
			}).then(res => {
				this.modal('提示', '申请接单成功')
				this.getGoodsInfo()
			})
		},
		async getGoodsInfo() {
			try {
				let res = await this.request('Order/TaskDetails', {
					queryId: this.id
				})
				console.log('任務詳情 API 返回:', res)
				if (!res || res.code != 200 || !res.data) {
					this.toast(res?.msg || '獲取任務詳情失敗')
					return
				}
				this.data = res.data
				this.info = res.data.info || {}
				if (!this.data.goodsImgList) {
					this.data.goodsImgList = []
				}
				this.updateCountdown()
				this.startCountdown()
			} catch (err) {
				console.error('任務詳情 API 異常:', err)
				this.toast('網絡錯誤，請重試')
			}
		},
		previewImages(urls, index) {
			uni.previewImage({ urls, current: index });
		},
		startCountdown() {
			this.timer = setInterval(() => {
				this.updateCountdown()
			}, 1000)
		},
		updateCountdown() {
			const now = new Date().getTime()
			const target = new Date(this.info.receivingTime).getTime()
			const distance = target - now
			if (distance <= 0) {
				this.countdown = { days: '00天', hours: '00時', minutes: '00分', seconds: '00秒' }
				this.stopCountdown()
				return
			}
			const days = Math.floor(distance / (1000 * 60 * 60 * 24))
			const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
			const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
			const seconds = Math.floor((distance % (1000 * 60)) / 1000)
			this.countdown = {
				days: days.toString().padStart(2, '0') + '天',
				hours: hours.toString().padStart(2, '0') + '時',
				minutes: minutes.toString().padStart(2, '0') + '分',
				seconds: seconds.toString().padStart(2, '0') + '秒'
			}
		},
		stopCountdown() {
			if (this.timer) {
				clearInterval(this.timer)
				this.timer = null
			}
		}
	},
	onShareAppMessage() {
		return {
			title: this.data.name,
			path: `/pagesShop/task/detail?id=${this.id}`
		}
	}
}
</script>

<style lang="scss" scoped>
.swiper {
	width: 750rpx;
	height: 750rpx;
}

.countdown {
	background: linear-gradient(90deg, #FF6B6B 0%, #FF8E53 100%);
	position: relative;
	overflow: hidden;
	padding: 24rpx 32rpx;

	.countdown-bg {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.countdown-left {
		.price {
			font-weight: 600;
			font-size: 48rpx;
			color: #FFFFFF;
		}
		.text {
			margin-top: 8rpx;
			font-size: 24rpx;
			color: rgba(255,255,255,0.9);
		}
	}

	.countdown-right {
		text-align: right;
		.title {
			font-size: 32rpx;
			font-weight: bold;
			color: #FFFFFF;
			margin-bottom: 8rpx;
		}
		.time {
			display: flex;
			align-items: center;
			.text {
				font-size: 22rpx;
				color: #FFFFFF;
				padding-right: 10rpx;
			}
			.num {
				font-weight: 600;
				font-size: 22rpx;
				color: #FF6B6B;
				background: white;
				padding: 6rpx 10rpx;
				border-radius: 6rpx;
				margin: 0 4rpx;
			}
		}
	}
}

.squareList {
	padding: 24rpx 28rpx;

	.square {
		background: #FFFFFF;
		border-radius: 16rpx;
		padding: 24rpx;
		margin-bottom: 24rpx;

		.prices {
			display: flex;
			justify-content: space-between;
			align-items: center;

			.price {
				font-weight: 600;
				font-size: 40rpx;
				color: #DE4343;
			}

			.texts {
				display: flex;
				align-items: center;
				.text {
					font-size: 24rpx;
					color: #666666;
				}
				image {
					margin-left: 10rpx;
					width: 30rpx;
					height: 30rpx;
				}
			}
		}

		.intro {
			margin-top: 16rpx;
			font-weight: 600;
			font-size: 32rpx;
			color: #333333;
			line-height: 1.5;
		}

		.item {
			display: flex;
			padding: 24rpx 0;

			.label {
				font-size: 28rpx;
				color: #666666;
				white-space: nowrap;
				width: 120rpx;
			}

			.right {
				margin-left: 24rpx;
				flex: 1;
				font-size: 28rpx;
				color: #333333;
			}
		}

		.item:not(:last-child) {
			border-bottom: 1rpx solid #F0F0F0;
		}
	}
}

.btnBox {
	position: fixed;
	left: 0;
	bottom: 0;
	width: 100%;
	padding: 22rpx 32rpx;
	background: #FFFFFF;
	box-shadow: 0rpx -4rpx 16rpx rgba(0, 0, 0, 0.05);

	.btnBuy {
		width: 100%;
		font-size: 32rpx;
		color: #FFFFFF;
		background: #8C4FFF;
		border-radius: 16rpx;
		padding: 28rpx 0;
		text-align: center;
		font-weight: 500;
	}
}
</style>
